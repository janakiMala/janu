package com.service;

import com.model.HelperBean;

//use appropriate annotation to configure HelperService as a Service
public class HelperService {
	
	
	//calculate the totalCost and return the cost
	public double calculateTotalCost(HelperBean helperBean)
	{
		
		return 0.0;
		
		
	}

}
	 	  	    	    	     	      	 	
