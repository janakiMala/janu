package com.controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.model.HelperBean;

//use appropriate annotation to configure HelpController as Controller
public class HelpController {
	
	
	
	
	
	//invoke the service class - calculateTotalCost method.
	public String calculateTotalCost(@ModelAttribute("helper") HelperBean helperBean,ModelMap model) {
			    return null;
			    
			}
	
	
}
	 	  	    	    	     	      	 	
